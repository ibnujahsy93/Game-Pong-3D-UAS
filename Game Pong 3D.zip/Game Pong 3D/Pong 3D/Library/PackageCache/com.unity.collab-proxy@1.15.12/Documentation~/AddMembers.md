# Add team members

To invite team members to contribute to your project:


1. Click the settings menu (gear icon) and click Invite Members to Workspace.

![Invite members to project](images/InviteMembers.png)

2. In the Plastic SCM cloud dashboard, click Add new user. 

You can also send invitations and add different permission types for each user.

