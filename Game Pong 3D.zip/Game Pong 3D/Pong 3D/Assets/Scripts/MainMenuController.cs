using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuController : MonoBehaviour
{
    public void PlayGameHorizontal()
    {
        SceneManager.LoadScene("Game Horizontal");
    }
    public void PlayGameVsBotHorizontal()
    {
        SceneManager.LoadScene("GamevsBot Horizontal");
    }
    public void PlayGameVertical()
    {
        SceneManager.LoadScene("Game Vertical");
    }
    public void PlayGameVsBotVertical()
    {
        SceneManager.LoadScene("GamevsBot Vertical");
    }
    public void PlayGameMix()
    {
        SceneManager.LoadScene("Game Mix");
    }
    public void PlayGameVsBotMix()
    {
        SceneManager.LoadScene("GamevsBot Mix");
    }


    public void HowToPlay()
    {
        SceneManager.LoadScene("How To Play");
    }
    public void ExitGame()
    {
        Application.Quit();
    }

    
}
