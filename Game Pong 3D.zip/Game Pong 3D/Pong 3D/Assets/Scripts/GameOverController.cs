using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverController : MonoBehaviour
{
    public GameObject pauseMenuUi;
    public bool GameIsPaused = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GameOver()
    {
        pauseMenuUi.SetActive(true);
        GameIsPaused = true;
    }

    public void ReplayHorizontal()
    {
        pauseMenuUi.SetActive(false);
        SceneManager.LoadScene("Game Horizontal");
        GameIsPaused = false;
    }
    public void ReplayHorizontalBot()
    {
        pauseMenuUi.SetActive(false);
        SceneManager.LoadScene("GamevsBot Horizontal");
        GameIsPaused = false;
    }
    public void ReplayVertical()
    {
        pauseMenuUi.SetActive(false);
        SceneManager.LoadScene("Game Vertical");
        GameIsPaused = false;
    }
    public void ReplayVerticalBot()
    {
        pauseMenuUi.SetActive(false);
        SceneManager.LoadScene("GamevsBot Vertical");
        GameIsPaused = false;
    }
    public void ReplayMix()
    {
        pauseMenuUi.SetActive(false);
        SceneManager.LoadScene("Game Mix");
        GameIsPaused = false;
    }
    public void ReplayMixBot()
    {
        pauseMenuUi.SetActive(false);
        SceneManager.LoadScene("GamevsBot Mix");
        GameIsPaused = false;
    }

    public void BackToMainMenu()
    {
        pauseMenuUi.SetActive(false);
        GameIsPaused = false;
        SceneManager.LoadScene("Main Menu");
    }
    public void ReplayvsBot()
    {
        pauseMenuUi.SetActive(false);
        SceneManager.LoadScene("GamevsBot");
        GameIsPaused = false;
    }
}
